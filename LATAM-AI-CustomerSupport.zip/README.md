# LATAM AI Customer Support

Sistema de soporte al cliente basado en agentes de IA, RAG y FastAPI.

## Instalación
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```
