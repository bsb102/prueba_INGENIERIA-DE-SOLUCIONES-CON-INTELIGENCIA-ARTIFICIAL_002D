import pandas as pd

def ingest():
    df = pd.read_csv('app/data/sample_faqs.csv')
    print("Datos cargados:", df.head())

if __name__ == "__main__":
    ingest()
