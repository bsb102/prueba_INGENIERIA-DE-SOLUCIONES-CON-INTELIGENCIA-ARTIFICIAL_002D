from fastapi import APIRouter

router = APIRouter()

@router.post("/")
def chat_endpoint(domain: str, question: str):
    return {"domain": domain, "answer": f"Respuesta simulada a: {question}"}
