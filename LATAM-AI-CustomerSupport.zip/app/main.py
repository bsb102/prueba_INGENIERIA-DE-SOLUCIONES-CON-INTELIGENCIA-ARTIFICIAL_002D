from fastapi import FastAPI
from app.api.v1 import chat

app = FastAPI(title="LATAM AI Customer Support")
app.include_router(chat.router, prefix="/api/v1/chat", tags=["chat"])

@app.get("/")
def root():
    return {"message": "API LATAM AI Customer Support en funcionamiento"}
