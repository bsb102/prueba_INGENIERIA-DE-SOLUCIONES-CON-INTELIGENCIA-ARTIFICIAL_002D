# Arquitectura

Este sistema usa FastAPI + agentes de IA + RAG.

- **FastAPI** expone la API.
- **Agentes** manejan reservas, quejas y fidelización.
- **Retriever (FAISS)** busca en las FAQs.
- **RAG** combina contexto con LLM.
